const youtuVid = [
    {
      title: "I am just ken",
      url: "https://www.youtube.com/embed/kW57PpibCMA",
    },
    {
        title: "Bet on it",
        url: "https://www.youtube.com/embed/n0p8MxT8AxI",
      },
      {
        title: "&quot;Toxic/Poison&quo",
        url: "https://www.youtube.com/embed/_EugT30D-6I?list=PLFs5StaXWEUD9SG3e0abND4i_WvpqFd-9",
      }
  ];
  
  export default youtuVid;
  


